#!/bin/sh
./bin/catalina.sh run
